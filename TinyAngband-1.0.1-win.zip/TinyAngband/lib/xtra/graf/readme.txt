The graphic files are available as a seperate archive from:

http://thangorodrim.angband.org/graf.zip

Robert Ruehlmann
rr9@angband.org

